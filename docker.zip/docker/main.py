#!/usr/local/bin/python3
import requests
import json
response = json.loads(requests.get("https://reqres.in/api/products/").text)
#print(response)
#print(json.dumps(response["data"]))
data=json.dumps(response["data"])
#print(data)
print("Content-type: text/html\n")
for element in (json.loads(data)):
    print("Name: "+element["name"])
#print(json.dumps(response["data"], indent=4, sort_keys=True))
